# Editor examples #

Double click on the field labels and the panel title to activate the editor.
