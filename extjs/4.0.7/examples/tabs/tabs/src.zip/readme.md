# Tabs Example #

## Tabs with auto height that resize to the content ##

Built from existing markup.

## Tabs with no tab strip and a fixed height that scroll the content##

Built entirely with JavaScript.

- Tab 1 is a normal tab with content passed when adding it.
- Tab 2 is loaded via Ajax each time the panel is visually activated.
- Tab 3 is loaded via Ajax only one time during panel construction. It was set up to pass parameters when loaded.
- Tab 4 has an event listener attached.
- Tab 5 is disabled.
