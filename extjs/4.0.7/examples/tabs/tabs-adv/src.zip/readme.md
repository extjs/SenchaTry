# Advanced Tabs #

This TabPanel is built entirely with JavaScript and demonstrates:

- Auto tab resizing
- Tab scrolling
- Tabs with icons
- Tab plugins (context menu)
- Adding tabs with JS
- Changing tab's closable property dynamically (via context menu)
