# Tab Scroller Menu Plugin #

This is an example of a TabPanel plugin that provides an overflow menu when there are more tabs than can be displayed in the tab strip. The sample also demonstrates the use of the `tabTip` config option to show custom QuickTips when you hover over any tab.
