# History Example #

This is a simple implementation of the `Ext.History` component for managing browser back/forward navigation within a single page.

It demonstrates managing history for multiple components within the page. Simply change tabs and use the browser Back and Forward buttons to navigate them.
