# Localization with Extjs #

This demonstrates multiple language with some of the Ext components.

Select a language from the combobox below (default is english) and try out the components in different languages.
