# Ext Slider Example #

Sliders support keyboard adjustments, configurable snapping, axis clicking and animation.
