# Ext SliderField Example #

Shows how the Slider control can be used in a form and participate like a form field.
