# Organizing Images into Albums #

This example shows demonstrates how you can drop anything into the tree.

This example also shows how a customized DragZone can be applied to a JsonView to get automatic lightweight drag and drop of asynchronously loaded data.

The multi image drag drop added a little complexity to the code, but hopefully it is still easy to follow.
