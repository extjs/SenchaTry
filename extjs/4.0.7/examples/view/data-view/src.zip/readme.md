# DataView Example #

This example shows how to use an Ext.view.View.  It demonstrates editable labels (click any of the photo labels), basic multi-select (using ctrl or shift) and drag selection.
