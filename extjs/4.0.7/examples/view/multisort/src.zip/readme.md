# Multisort DataView Example #

This example shows using multiple sorters on a Store attached to a DataView.

We're also using the reorderable toolbar plugin to make it easy to reorder the sorters with drag and drop.
