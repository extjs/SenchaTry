# Animated DataView Example #

This example uses the `Ext.ux.DataView.Animated` plugin to animate the changes to a DataView.
