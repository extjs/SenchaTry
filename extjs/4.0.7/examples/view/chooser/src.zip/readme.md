# Advanced DataView Example #

This example shows loading a DataView in a Window.  Each item has a linked details view, and the DataView supports custom sorting and filtering.
