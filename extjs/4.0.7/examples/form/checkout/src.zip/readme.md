# Checkout Form #

This shows an example of a common shopping cart checkout form. It demonstrates uses of FieldContainer and various layouts for arranging and aligning fields, ComboBox fields for state and month selection, and listening to change events to automatically copy values from Mailing Address to Billing Address fields.
