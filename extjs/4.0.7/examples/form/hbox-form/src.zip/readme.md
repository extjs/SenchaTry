# HBox Form Example #

In the following example, the space needed for the email validation error message automatically taken form the field size when needed.  The mousedown event is being used for validation for more immediate feedback.  Also note that the FormPanel itself is using an hbox layout as we can use any layout for forms now.
