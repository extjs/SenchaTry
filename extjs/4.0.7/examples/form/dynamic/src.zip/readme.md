# Dynamic Forms built with JavaScript #

These forms do not do anything and have very little validation. They solely demonstrate how you can use Ext Forms to build and layout forms on the fly.
