# Advanced Validation Examples Using VTypes #

The first example shows two date fields acting as a date range.  Selecting an initial date sets the minimum value for the end field.  Selecting an ending date sets a maximum value for the start field.

The second example shows a password verification, the second value must be equivalent to the first to validate.
