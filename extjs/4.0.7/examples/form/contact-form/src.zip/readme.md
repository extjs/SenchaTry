# Contact Form #

This shows an example of a common "Contact Us" form in a popup window. The form uses vbox and hbox layouts to acheive a uniform flexible layout even when the window is resized.
