# Combo with Templates and Ajax #

This is a more advanced example that shows how you can combine Ext.Template and a remote data store to create a "live search" feature. Try searching for terms like "form", or "grid".

Each item in the resulting list is a link which may be clicked to navigate to the found forum thread.
