# Checkbox / Radio Groups #

This demonstrates the flexible layout capabilities of the CheckboxGroup and RadioGroup classes. It also shows that you can validate checkboxes/radios as a group &mdash; try submitting the form before changing any values to see this.
