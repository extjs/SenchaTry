# Custom Form Fields #

Ext provides many types of form fields to build interactive and rich forms. However, it also provides a complete framework for building new types of fields quickly. The search field below is an example.
