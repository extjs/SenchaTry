# Custom Grid Filters Example (local filtering) #

This example demonstrates a custom Grid Filter Extension. It adds an item to each column header menu that allows filtering of that column.

**Note:** The remote filtering requires the SQLite PHP plugin be installed on the server. See [here](http://uk2.php.net/manual/en/sqlite.installation.php).
