# Locking Grid Column Example #

This example shows how to achieve "freeze pane" locking functionality similar to Excel.
