# Grouping Grid Example #

This example illustrates how to use the grouping feature of the Grid.
