# Paging Grid Example #

This example shows how to create a grid with paging. This grid uses a Ext.data.proxy.JsonP proxy to fetch cross-domain remote data (from the Ext forums).
