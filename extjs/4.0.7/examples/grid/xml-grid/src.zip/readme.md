# XML Grid Example #

This example shows how to load a grid with XML data.

The data in the grid is loaded from *sheldon.xml*, which is directly from an Amazon.com search.
