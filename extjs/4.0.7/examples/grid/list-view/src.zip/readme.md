# ListView Example #

Ext 4 replaces Ext.ListView with the default Ext.grid.Panel.
