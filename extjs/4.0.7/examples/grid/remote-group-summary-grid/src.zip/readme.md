# Remote Summary Grid Example Example #

This example demonstrates the use of the GroupingSummaryFeature with server-side summary calculation (results are intentionally wrong).
