# Live Search Grid Example #

This example shows how to create a grid with live search support.
