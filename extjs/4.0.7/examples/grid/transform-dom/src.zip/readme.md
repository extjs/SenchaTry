# From Markup Grid Example #

This example shows how to create a grid with from an existing, unformatted HTML table.
