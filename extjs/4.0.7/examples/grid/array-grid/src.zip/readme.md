# Stateful Array Grid Example #

This example shows how to create a grid from Array data.

The grid is stateful so you can move or hide columns, reload the page, and come back to the grid in the same state you left it in.
