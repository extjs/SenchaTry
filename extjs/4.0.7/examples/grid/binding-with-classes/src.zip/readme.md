# Data Binding Example - Implemented with classes #

This example expands upon the [Binding example](../binding/index.html). It shows how to implement the same functionality but in a more organized and object-oriented fashion
