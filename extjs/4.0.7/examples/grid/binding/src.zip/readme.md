# Data Binding Example #

This example expands upon the [XML Grid example](../xml-grid/index.html) and shows how to implement data binding for a master-detail view.

You can find a more advanced example of the same code which abstracts each piece of this simple application into multiple classes in [Data Binding Example - Implemented with classes](../binding-with-classes/index.html).
