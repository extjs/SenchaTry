# Infinite Scrolling #

Ext JS 4's brand new grid supports infinite scrolling, which enables you to load any number of records into a grid without paging.

The new grid uses a virtualized scrolling system to handle potentially infinite data sets without any impact on client side performance.
