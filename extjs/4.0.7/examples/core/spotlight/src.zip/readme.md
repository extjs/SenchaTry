# Spotlight Example #

This utility allows you to restrict input to a particular element by masking all other page content.
