# Drag and Drop between two TreePanels #

The TreePanels have a TreeSorter applied in "folderSort" mode.

Both TreePanels are in "appendOnly" drop mode since they are sorted.

Drag along the edge of the tree to trigger auto scrolling while performing a drag and drop.

The data for this tree is asynchronously loaded with a JSON TreeLoader.
