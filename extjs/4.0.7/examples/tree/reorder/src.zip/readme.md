# Drag and Drop ordering in a TreePanel #

This example shows basic drag and drop node moving in a tree. In this implementation there are no restrictions and anything can be dropped anywhere except appending to nodes marked "leaf" (the files).

In order to demonstrate drag and drop insertion points, sorting was *not* enabled.

The data for this tree is asynchronously loaded through a TreeStore and AjaxProxy.
