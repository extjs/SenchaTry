# XML Tree Example #

This example is the same as the Tree sample, however it loads from an XML data source.
