# Checkbox Selection in a TreePanel #

This example shows simple checkbox selection in a tree. It is enabled on leaf nodes by simply setting `checked:true/false` at the node level.

This example also shows loading an entire tree structure statically in one load call, rather than loading each node asynchronously.
