# TreeGrid Example #

This example is an advanced tree example. It illustrates:

- Multiple headers
- Preloading of nodes with a single AJAX request
- Header hiding, showing, reordering and resizing 
- useArrows configuration
- Keyboard Navigation
- Discontinguous selection by holding the CTRL key
- Using custom iconCls
- singleExpand has been set to true
