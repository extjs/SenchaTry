# Drag and Drop from a Data Grid to a Form Panel #

This example shows how to setup a one way drag and drop from a grid to an instance of an Ext.form.Panel.
