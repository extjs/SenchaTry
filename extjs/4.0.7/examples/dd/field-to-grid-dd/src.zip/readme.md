# Using a GridPanel as a DropZone managing each grid cell as a target #

This example assumes prior knowledge of using a GridPanel.

This illustrates how a DragZone can manage an arbitrary number of drag sources, and how a DropZone can manage an arbitrary number of targets.
