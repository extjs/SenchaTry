# Rotating Text with a Draw Component #

In this example, you can see how easy it is to create text in a Draw Component which can be rotated easily in any browser. Use the slider to spin the text 360 degrees.

See our introductory blog post on the topic [here](http://www.sencha.com/blog/ext-js-4-drawing-charting).
