# Reorderable Toolbars #

This toolbar has the `Ext.BoxReorderer` plugin applied to it.

Each item in the Toolbar has an optional `reorderable` property, which will make the button draggable if set to true. In this example the 4 rightmost buttons are reorderable.
