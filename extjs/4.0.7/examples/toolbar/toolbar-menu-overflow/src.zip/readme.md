# Horizontal Toolbar Example #

This example demonstrates use of the 'Menu' box layout overflow handler to display items of a Toolbar which overflow the available width.
