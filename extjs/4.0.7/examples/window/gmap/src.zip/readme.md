# GMap Window #

This example shows how to create an extension and utilize an external library.
