# Windows with Layouts #

This example shows how Ext containers can be nested in windows to create advanced layouts.
