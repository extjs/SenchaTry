# Ext Buttons #

Shows buttons in many of their possible configurations.

For a demo of buttons in toolbars, see [the toolbar sample](../toolbar/).
