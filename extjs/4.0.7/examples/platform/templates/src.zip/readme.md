# Templates Example #

This example shows how to use Ext.Template and Ext.XTemplate.
