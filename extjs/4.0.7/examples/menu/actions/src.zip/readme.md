# Using Ext.Action #

Actions let you share handlers, configuration and updates across Toolbar, Button and Menu components.
