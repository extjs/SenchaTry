# MessageBox Dialogs #

The example shows how to use the MessageBox class. Some of the buttons have animations, some are normal.
