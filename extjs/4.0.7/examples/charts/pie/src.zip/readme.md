# Pie Chart Example#

Display 5 sets of random data using a pie chart. Reload data will randomly generate a new set of data in the store.  Toggle Donut button will dynamically change the chart between a Donut and Pie chart. Click or hover on the legend items to highlight and remove them from the chart. In addition contrast detection has been turned on to dynamically change the font color based on the color of the item it is on.
