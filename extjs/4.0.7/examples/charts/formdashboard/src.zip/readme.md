# Dynamic Form, Grid and Charts #

Showing companies information in a grid. Selecting a row will highlight the bar corresponding to that company and fill in the form with the company data. A radar chart will show the company information. You can update the information in the form to see it change live in the grid, bar chart and radar charts.
