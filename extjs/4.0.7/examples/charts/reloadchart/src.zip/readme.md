# Reload Column Chart Sample #

Displaying a Column Chart Sample that animates when refreshing the data set.
