# Gauge Chart #

Displaying three custom gauge charts bound to different data stores with different configuration options and easings. Click on **Reload Data** to update the information.
