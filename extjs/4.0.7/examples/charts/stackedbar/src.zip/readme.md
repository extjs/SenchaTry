# Stacked Bar Chart Sample #

Showing movie taking by genre as a stacked bar chart sample. Filter the stacks by clicking on the legend items.
