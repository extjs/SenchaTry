# Area Chart Example #

Display 7 sets of random data in an area series. Reload data will randomly generate a new set of data in the store. Click or hover on the legend items to highlight and remove them from the chart.  The bottom axis has had it's labels rotated.