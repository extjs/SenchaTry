# Bar Renderer #

Displaying a horizontal bar series with a bar renderer that modifies the color of each bar.