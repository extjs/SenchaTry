# Column Chart #

Display a sets of random data in a column series. Reload data will randomly generate a new set of data in the store.
