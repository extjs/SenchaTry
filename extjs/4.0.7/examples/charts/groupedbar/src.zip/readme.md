# Grouped Bar Chart #

Display 3 sets of random data in a grouped bar series. Reload data will randomly generate a new set of data in the store. Click or hover on the legend items to highlight and remove them from the chart.
