# Pie Renderer Example #

Display 5 sets of random data using a pie chart. Reload data will randomly generate a new set of data in the store. A renderer has been set up on to dynamically change the length and color of each slice based on the data.  In addition contrast detection has been turned on to dynamically change the font color based on the color of the item it is on.
