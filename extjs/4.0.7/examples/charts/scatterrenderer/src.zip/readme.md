# Scatter Renderer Example #

Display 2 sets of random data in a scatter series. A renderer has been set up on to dynamically change the size and color of the items based upon it's data. In addition contrast detection has been turned on to dynamically change the font color based on the color of the item it is on. Reload data will randomly generate a new set of data in the store.
