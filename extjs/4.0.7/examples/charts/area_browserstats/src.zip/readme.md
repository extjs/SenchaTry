# Area - BrowserStats #

Display browser usage trends in an area series. This chart uses custom gradients for the colors and the legend is interactive.  Click or hover on the legend items to highlight and remove them from the chart.