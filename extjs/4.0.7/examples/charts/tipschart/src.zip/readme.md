# Chart in tips example #

Showing a Pie Chart and a Grid Panel as elements in a tooltip.
