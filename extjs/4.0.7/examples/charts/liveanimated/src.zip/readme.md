# Live Updated Chart - Animated #

Display 3 sets of random data in a line series. In this example, random data is added to the store every 1000ms and a 500ms animation will occur to animate the change visually.  The chart will scroll and the bottom axis will update once the line reaches the right side of the chart.

See our introductory blog post on the topic [here](http://www.sencha.com/blog/ext-js-4-drawing-charting).
