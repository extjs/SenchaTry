# Mixed Charts Example #

Display 3 sets of random data using a line, bar, and scatter series. Reload data will randomly generate a new set of data in the store.
