# Stacked Bar Chart Sample #

Display a sets of random data in a bar series. Reload data will randomly generate a new set of data in the store.