# Radar Sample #

Display 3 sets of random data in a radar series. Reload data will randomly generate a new set of data in the store.  Note this example uses a radial axis.
