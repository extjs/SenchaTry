# Resizable Examples #

These examples show how to apply a floating (default) and pinned Resizable component to a standard element.
