# Ext.draw.Component Example #
