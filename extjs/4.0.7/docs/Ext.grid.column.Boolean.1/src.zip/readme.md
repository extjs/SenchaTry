# Ext.grid.column.Boolean Example #
