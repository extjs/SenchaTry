# Ext.chart.axis.Category Example #
