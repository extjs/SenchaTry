/*global Ext:false */
Ext.onReady(function () {
    Ext.Msg.alert('Status', 'Changes saved successfully.');
});
