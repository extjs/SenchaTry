# Ext.tip.QuickTipManager Example #
