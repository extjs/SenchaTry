# Ext.chart.series.Scatter Example #
