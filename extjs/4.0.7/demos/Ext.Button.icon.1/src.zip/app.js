/*global Ext:false */
Ext.application({
    name: 'Ext.Array.clean()',
    launch: function () {
        Ext.create('Ext.Button', {
            text: 'I\'m a button!',
            icon: 'http://sencha.com/favicon.ico',
            renderTo: Ext.getBody()
        });
    } // launch
}); // Ext.application()
