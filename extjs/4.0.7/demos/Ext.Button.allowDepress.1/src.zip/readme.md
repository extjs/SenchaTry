# Preventing an Ext.Button component from being depressed in Ext JS #

The following example shows how you can prevent an Ext.Button component from being depressed by setting the Boolean `allowDepress` config to `false`.
