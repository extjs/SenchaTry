# Displaying a simple dialog message using the Ext.Msg class #

The following example shows how you can create a simple dialog message using the static `Ext.Msg.show()` method and passing an explicit config object.
