# Setting the size of an Ext.Button component using Ext JS #

The following example shows how you can set the vertical size/scale of an Ext.Button in Ext JS by setting the `scale` config or using the `setScale()` method.
