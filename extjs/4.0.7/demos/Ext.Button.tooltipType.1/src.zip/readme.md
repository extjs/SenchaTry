# Adding tooltips to an Ext.Button component using Ext JS #

The following example shows how you can create tooltips on an Ext.Button control by setting the `tooltip` config (and optionally the `tooltipType` config).
