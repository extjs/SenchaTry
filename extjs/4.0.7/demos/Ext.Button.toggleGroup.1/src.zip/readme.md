# Creating a group of toggled Ext.Button components in Ext JS #

The following example shows how you can create a group of related toggle Ext.Button components in Ext JS by setting the `toggleGroup` config. When two or more Ext.Button components share the same value for the `toggleGroup` config, only one of those buttons can be toggled at a time.
