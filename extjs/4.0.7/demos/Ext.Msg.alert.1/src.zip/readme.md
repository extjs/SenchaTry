# Displaying a simple alert message using the Ext.Msg class #

The following example shows how you can create a simple modal alert message using the static `Ext.Msg.alert()` method.
