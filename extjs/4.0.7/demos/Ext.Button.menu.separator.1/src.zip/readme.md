# Adding a horizontal separator bar to an Ext.menu.Menu component in Ext JS #

The following example shows how you can add a horizontal separator bar to an Ext.menu.Menu component in Ext JS by adding an '-' item to the list of items, or by explicitly adding an `Ext.menu.Separator` instance using the `menuseparator` xtype.
