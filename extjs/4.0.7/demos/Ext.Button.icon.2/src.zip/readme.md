# Displaying an icon on a Button component using Ext JS #

The following example shows how you can display an icon on an Ext.Button control by setting the `icon` property to a file path or a data URI.
