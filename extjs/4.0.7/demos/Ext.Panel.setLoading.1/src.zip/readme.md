# Adding a loading mask to an Ext.panel.Panel container in Ext JS #

The following example shows how you can add a loading mask to an Ext.panel.Panel container in Ext JS by calling the `setLoading()` method. You can clear the loading mask by calling the `setLoading()` method and passing `false`.
