# Programmatically closing an alert dialog using Ext JS #

The following example shows how you can programmatically close an Ext.Msg dialog box using the `close()` method.
