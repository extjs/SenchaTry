# Disabling an Ext.Button component in Ext JS #

The following example shows how you can disable an Ext.Button component in Ext JS by setting the Boolean `disabled` config or by calling the `setDisabled()` method at runtime.
