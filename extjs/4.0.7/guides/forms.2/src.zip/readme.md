# The Form Package Example #

The Form package enables you to create powerful forms backed with the Ext Data package.
