# Components Example #

A simple example, and videos, about how to create components in Ext JS.
