# Tree Example #

Tree and grid now both extend from the same base class. All of the benefits of grid can now be used on trees.
