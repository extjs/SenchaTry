# Individual Column Filter #

Grid column individually filtered through combos.

Via [Luis Enrique Martínez Gómez](http://www.codetlan.com).