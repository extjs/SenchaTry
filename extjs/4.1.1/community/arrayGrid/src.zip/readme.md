# ExtJS 4 + Sencha Architect 2: Basic Array Grid Example (using ActionColumn) #

Basic Array Grid example ported to ExtJS 4 and Sencha Architect 2. This example also uses ActionColumn and shows how to handle it in Sencha Architect 2.

Sencha Architect 2 (files included)

[Blog post](http://loianegroner.com/2012/06/extjs-4-sencha-architect-2-basic-array-grid-example-using-actioncolumn/)

Via [Loiane Groner](http://loianegroner.com).
