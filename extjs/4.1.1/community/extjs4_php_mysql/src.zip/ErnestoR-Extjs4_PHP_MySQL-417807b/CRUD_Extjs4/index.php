<!DOCTYPE html>
<html>
<head>
    <title>User CRUD</title>

    <link rel="stylesheet" type="text/css" href="extjs/resources/css/ext-all.css">
    
    <script type="text/javascript" src="extjs/ext-all-debug.js"></script>
    <link rel="stylesheet" href="resources/style.css" type="text/css">
    <script type="text/javascript" src="app.js"></script>
</head>
<body>
</body>
</html>
