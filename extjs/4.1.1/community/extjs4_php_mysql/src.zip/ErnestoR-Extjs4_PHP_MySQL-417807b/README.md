<h1>Extjs 4 PHP MySQL</h1>
This source code covers a lot of Extjs 4 especially MVC architecture, Stores, Models and Controllers. I highly recommend that you read and attempt to do this tutorial (http://docs.sencha.com/ext-js/4-0/#!/guide/application_architecture) before getting started with the php and mysql.

Here are the instructions:

1) Unzip CRUD_Extjs4.zip to your web environment<br />
2)Create Mysql Database: CRUD_Extjs4<br />
3)Execute the sql file: CRUD_Extjs4.sql in the database.<br />
4)Run CRUD_Extjs4 on your server. :)<br />
