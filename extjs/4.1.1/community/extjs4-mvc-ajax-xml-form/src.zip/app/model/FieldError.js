Ext.define('ExtMVC.model.FieldError',{
    extend: 'Ext.data.Model',
    fields: ['id', 'msg']
});
