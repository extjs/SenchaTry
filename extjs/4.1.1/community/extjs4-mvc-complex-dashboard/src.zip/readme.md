# ExtJS 4 MVC Complex Dashboard Example #

Ported Complex Dashboard Example to MVC

Via [Loiane Groner](http://loianegroner.com/).
