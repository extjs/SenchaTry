# Grid with a busy Toolbar #

Example shows using `loadRawData(data)` with JSON store and field mappings. Plus a very busy toolbar.

Via [Dmitry Brin](http://www.sencha.com/forum/member.php?106520-dbrin).
