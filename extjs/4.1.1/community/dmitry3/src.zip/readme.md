# Simple Viewport and MVC in ExtJS4 #

An example of a menu that closes automatically after a mouseleave event.

Via [Dmitry Brin](http://www.sencha.com/forum/member.php?106520-dbrin).
