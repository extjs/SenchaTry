# ExtJS 4 Example using Ext.flash.ComponentView component #

This example shows how to add a flash file (.swf) inside an ExtJS 4 Component.

[Blog post - step by step](http://loianegroner.com/2012/07/tutorial-adding-a-flash-file-inside-an-extjs-4-component/)

Via [Loiane Groner](http://loianegroner.com).
