# ExtJS 4 Basic Array Grid - MVC (with Action Columns) #

Ported Basic Array Grid example to MVC

Via [Loiane Groner](http://loianegroner.com/).
