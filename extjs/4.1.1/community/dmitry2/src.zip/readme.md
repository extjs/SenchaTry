# Simple Viewport and MVC in ExtJS4 #

MVC example of using a viewport, border layout, menu, toolbar, etc.

Via [Dmitry Brin](http://www.sencha.com/forum/member.php?106520-dbrin).
