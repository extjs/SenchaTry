Ext.define('ExtMVC.store.ChartStocks', {
    extend: 'Ext.data.JsonStore',
    model: 'ExtMVC.model.ChartStock'
});
