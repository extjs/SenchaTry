Ext.define('Sample.deadlock.D', {
    extend: 'Sample.deadlock.E'
});