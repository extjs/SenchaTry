extjs4-mvc-multiselect
======================

ExtJS 4 MVC Multiselect/ItemSelector Examples