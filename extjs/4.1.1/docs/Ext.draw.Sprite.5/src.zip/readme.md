# Ext.draw.Sprite Example #
