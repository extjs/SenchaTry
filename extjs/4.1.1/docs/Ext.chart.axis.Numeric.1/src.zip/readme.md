# Ext.chart.axis.Numeric Example #
