# Ext.draw.Text Example #
