/*global Ext:false */
Ext.onReady(function () {
    Ext.create('Ext.Button', {
        renderTo: document.body,
        text: 'Click me',
        scale: 'large'
    });
});
