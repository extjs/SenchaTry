# Ext.chart.series.Bar Example #
