# Ext.menu.ColorPicker Example #
