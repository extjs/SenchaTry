# Checking whether an array contains a specific value using the Ext.Array class #

The following example shows how you can determine if an array contains a specific value using the static `Ext.Array.contains()` method.
