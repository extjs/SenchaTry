# Setting the menu arrow alignment on an Ext.Button component using Ext JS #

The following example shows how you can set the menu arrow alignment on an Ext.Button component in Ext JS by setting the `arrowAlign` config option.
