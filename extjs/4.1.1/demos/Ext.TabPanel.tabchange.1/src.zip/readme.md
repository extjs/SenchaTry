# Determining when the user changes the active tab in an Ext.TabPanel container in Ext JS #

The following example shows how you can determine when the user changes the active tab in an Ext.TabPanel container in Ext JS by listening for the `tabchange` event.
