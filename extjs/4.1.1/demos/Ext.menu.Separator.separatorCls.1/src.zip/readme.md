# Styling the horizontal separator bar on an Ext.menu.Menu component in Ext JS #

The following example shows how you can add a custom CSS class to the horizontal separator by specifying the `separatorCls` config on the `menuseparator` xtype object.
