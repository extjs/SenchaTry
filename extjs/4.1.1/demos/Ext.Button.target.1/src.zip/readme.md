# Loading a new page when a user clicks an Ext.Button component in Ext JS #

The following example shows how you can load a new page when a user clicks an Ext.Button component in Ext JS by setting the `href` (or `url`) config.
