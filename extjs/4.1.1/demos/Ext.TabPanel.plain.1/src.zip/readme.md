# Removing the tab bar background fill on an Ext.TabPanel container in Ext JS #

The following example shows how you can remove the tab bar background fill on an Ext.TabPanel container in Ext JS by setting the Boolean `plain` config to `true`.
