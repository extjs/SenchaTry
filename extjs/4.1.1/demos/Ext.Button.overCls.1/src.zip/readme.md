# Specifying custom hover and pressed styles on an Ext.Button component using Ext JS #

The following example shows how you can specify custom classes for hover and pressed states on an Ext.Button component in Ext JS by setting the `overCls` config and `pressedCls` config to a CSS selector name.
