# Changing the icon in a dialog box using Ext JS #

The following example shows how you can change the displayed icon in a Ext.Msg dialog box using the `setIcon()` method.
