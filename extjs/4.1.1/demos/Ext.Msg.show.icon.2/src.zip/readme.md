# Displaying an icon in a dialog box using Ext JS #

The following example shows how you can specify an icon in an Ext.Msg dialog box using the static `Ext.Msg.show()` method and specifying the Boolean `icon` config option.
