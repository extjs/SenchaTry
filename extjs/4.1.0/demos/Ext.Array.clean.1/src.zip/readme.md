# Removing empty elements from an array using the Ext.Array class #

The following example shows how you can remove empty elements from an array using the static `Ext.Array.clean()` method.
