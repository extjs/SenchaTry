# Setting the text label alignment on an Ext.Button component in Ext JS #

The following example shows how you can set the text label alignment on an Ext.Button component in Ext JS by setting the `textAlign` config.
