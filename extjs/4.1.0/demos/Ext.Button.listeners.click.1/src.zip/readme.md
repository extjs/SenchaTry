# Adding a click handler to an Ext.Button component in Ext JS #

The following example shows how you can add a simple click handler to the Ext.Button component in Ext JS using the `handler` property or the `listeners` property and listening for the `click` event.
