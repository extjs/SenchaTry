# Closing an Ext.menu.Menu component when the user toggles a menu checkbox item in Ext JS #

The following example shows how you can automatically close an Ext.menu.Menu component when a user clicks on an Ext.menu.CheckItem component by setting the Boolean `hideOnClick` config object.
