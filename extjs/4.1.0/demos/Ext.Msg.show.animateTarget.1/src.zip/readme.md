# Animating a dialog box using the Ext.Msg class and Ext JS #

The following example shows how you can add an animation when a dialog box opens and closes on an Ext.Msg dialog box using the static `Ext.Msg.show()` method and specifying the `animateTarget` config option.
