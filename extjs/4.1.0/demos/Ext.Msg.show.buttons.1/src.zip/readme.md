# Specifying which buttons appear in a dialog box using the Ext.Msg class and Ext JS #

The following example shows how you can specify which buttons appear in an Ext.Msg dialog box using the static `Ext.Msg.show()` method and specifying the `buttons` config option.
