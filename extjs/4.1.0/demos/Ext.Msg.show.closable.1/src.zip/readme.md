# Toggling the close button on a dialog box in Ext JS #

The following example shows how you can specify whether the top-right close button buttons appears in an Ext.Msg dialog box using the static `Ext.Msg.show()` method and specifying the Boolean `closable` config option.
