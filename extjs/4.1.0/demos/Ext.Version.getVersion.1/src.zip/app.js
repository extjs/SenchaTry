/*global Ext:false */
Ext.onReady(function () {
    Ext.Msg.show({title: 'Built using Sencha Ext JS ' + Ext.getVersion('extjs'),
        closable: false});
});
