# Determining the application Ext JS framework version number using Ext JS #

The following example shows how you can determine which version of the Ext JS framework the current application is targeting by using the `Ext.getVersion()` method.
