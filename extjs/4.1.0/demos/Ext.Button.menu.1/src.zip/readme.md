# Adding a submenu to an Ext.Button component using Ext JS #

The following example shows how you can add a simple submenu to an Ext.Button component in Ext JS by setting the `menu` config option.
