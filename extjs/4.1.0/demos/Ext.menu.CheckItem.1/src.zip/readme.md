# Adding a checkbox control to an Ext.menu.Menu component in Ext JS #

The following example shows how you can add a checkbox control to an Ext.menu.Menu component in Ext JS by specifying an `xtype` of `"menucheckitem"` on a menu item.
