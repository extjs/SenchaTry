# Determining which button the user clicked to dismiss an Ext.Msg dialog using Ext JS #

The following example shows how you can determine which button the user clicked to close an Ext.Msg dialog box using the static `Ext.Msg.show()` method and specifying the `fn` config option.
