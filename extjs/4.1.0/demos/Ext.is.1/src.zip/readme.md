# Determining the user's platform using Ext JS #

The following example shows how you can determine the current platform the application is running on using the static properties in the `Ext.is` class.
