# Creating a simple toggle Ext.Button component in Ext JS #

The following example shows how you can create a simple toggle Ext.Button component in Ext JS by setting the Boolean `enableToggle` config to `true`. You can check whether the button instance is toggled at runtime by checking the Boolean `pressed` config.
