# Ext.chart.series.Gauge Example #
