# Ext.toolbar.TextItem Example #
