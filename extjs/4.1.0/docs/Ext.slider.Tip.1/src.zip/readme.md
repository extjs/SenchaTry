# Ext.slider.Tip Example #
