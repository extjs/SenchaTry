# Ext.chart.series.Area Example #
