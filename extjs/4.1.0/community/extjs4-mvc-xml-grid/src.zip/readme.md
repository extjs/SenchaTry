# ExtJS 4 XML Grid - MVC #

Ported XML Grid example to MVC

Via [Loiane Groner](http://loianegroner.com/).
