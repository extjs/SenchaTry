# ExtJS 4 MVC Paging Grid Example #

Ported Paging Grid Example example to MVC

Via [Loiane Groner](http://loianegroner.com/).
