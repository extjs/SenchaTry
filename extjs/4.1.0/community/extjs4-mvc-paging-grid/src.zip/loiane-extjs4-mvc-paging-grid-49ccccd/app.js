Ext.application({
    name: 'ExtMVC',

    paths: { 'Ext.ux': 'extjs/ux/' },

    controllers: [
        'ForumThreads'
    ],

    autoCreateViewport: true
});