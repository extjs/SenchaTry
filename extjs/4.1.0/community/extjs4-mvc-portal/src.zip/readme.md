# ExtJS 4 MVC Portal Example #

Ported Portal Example to MVC

Via [Loiane Groner](http://loianegroner.com/).
