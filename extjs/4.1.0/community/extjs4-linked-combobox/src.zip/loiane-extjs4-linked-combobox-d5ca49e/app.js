Ext.Loader.setConfig({enabled: true});

Ext.application({
    name: 'ExtMVC',

    controllers: [
        'LinkedComboboxes'
    ],

    autoCreateViewport: true
});