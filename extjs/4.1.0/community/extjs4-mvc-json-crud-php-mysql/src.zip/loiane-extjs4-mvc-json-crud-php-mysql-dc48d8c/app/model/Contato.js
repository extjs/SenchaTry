Ext.define('ExtMVC.model.Contato', {
    extend: 'Ext.data.Model',
    fields: ['id', 'name', 'phone', 'email']
});