Ext.application({
    name: 'ExtMVC',

    controllers: [
        'Contacts'
    ],

    autoCreateViewport: true
});