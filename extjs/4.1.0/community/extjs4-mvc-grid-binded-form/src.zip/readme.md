# ExtJS 4 MVC - Grid binded to a Form #

Ported Grid binded to a Form example to MVC

Via [Loiane Groner](http://loianegroner.com/).
