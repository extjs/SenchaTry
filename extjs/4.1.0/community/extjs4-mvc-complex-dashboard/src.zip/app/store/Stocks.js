Ext.define('ExtMVC.store.Stocks', {
    extend: 'Ext.data.ArrayStore',
    model: 'ExtMVC.model.Stock'
});
