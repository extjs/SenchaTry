Ext.define('ExtMVC.model.RadarDataSet', {
	extend: 'Ext.data.Model',
	fields: ['Name', 'Data']
});