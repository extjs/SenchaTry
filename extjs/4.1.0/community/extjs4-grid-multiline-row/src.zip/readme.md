# ExtJS 4 Example: Multiline Row in a Grid #

Complete explanation: http://loianegroner.com/2012/05/extjs-4-example-multiline-row-in-a-grid/

Via [Loiane Groner](http://loianegroner.com/).
