# Device APIs #
