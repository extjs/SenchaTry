Ext.define('Kitchensink.view.Cube', {
    extend: 'Ext.Panel',
    config: {
        cls: 'card card1',
        html: 'Cube Animation'
    }
});
