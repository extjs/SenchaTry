/**
 * This is a simple utility class that just renders a bunch of lorem ipsum text
 */
Ext.define('Kitchensink.view.LoremIpsum', {
    extend: 'Ext.Component',
    xtype: 'loremipsum',
    config: {
        html: "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In tempus libero ut mi porta tristique. Sed vel nulla metus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris imperdiet lobortis sem at placerat. Phasellus vitae quam arcu, sit amet vehicula urna. Vivamus rutrum cursus tempor. Fusce ullamcorper dolor a dolor vestibulum vitae viverra purus sollicitudin. Cras elit augue, lacinia id placerat nec, eleifend eu justo. Aliquam pellentesque ante ut lacus pharetra facilisis. Praesent varius accumsan nibh imperdiet porta. Duis eget mauris urna. Sed dictum felis eu metus consectetur ultricies. Aliquam erat volutpat. Donec cursus mauris quis sapien luctus quis consectetur leo mattis. Etiam sed magna purus.</p><p>Maecenas adipiscing ligula in urna dignissim dapibus. Maecenas vehicula, nisi sit amet ultricies placerat, orci tellus euismod nisl, vehicula lacinia nulla lectus at magna. Sed id orci est. Phasellus eget ultrices mauris. Ut elementum semper facilisis. Cras fermentum, leo vel elementum ornare, mauris lorem vehicula elit, adipiscing mollis enim magna vel ipsum. Proin sagittis, sapien vitae dignissim sodales, metus turpis sodales lacus, eget scelerisque nunc magna auctor tortor. Sed sagittis mi sit amet risus pretium vulputate vel eget sapien.</p>"
    }
});
