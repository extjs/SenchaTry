Ext.define('Oreilly.store.SessionSpeakers', {
    extend: 'Ext.data.Store',

    config: {
        model: 'Oreilly.model.Speaker'
    }
});
