/*global Ext:false */
Ext.application({
    name: 'Sencha',

    launch: function () {
        alert('launched');
    }
});
