# Using Components in Sencha Touch 2 #

All of the Components in Sencha Touch follow the same pattern and API conventions - this guide teaches you all about it.
