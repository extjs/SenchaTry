# Using Forms in Sencha Touch 2 #

Introduces Form Panels and the fields that they can contain. Shows how to load data, submit to the server and more.
