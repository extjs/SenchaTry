# Using DataViews in Sencha Touch 2 #

DataViews are a great way to generate lots of components based on a Store. Great for lists, mailboxes, settings screens and more.
