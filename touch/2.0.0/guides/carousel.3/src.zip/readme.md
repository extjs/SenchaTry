# Using Carousels in Sencha Touch 2 #

Carousels allow you to swipe between screens and work well on tablets and phone screens.
