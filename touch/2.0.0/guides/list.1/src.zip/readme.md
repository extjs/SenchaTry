# Using Lists in Sencha Touch 2 #

Lists are great at showing lots of information, and pack loads of functionality in out of the box. Find out how to use them here.
