# Floating Components #

A quick guide on how you can center and absolute position your components using Sencha Touch.
