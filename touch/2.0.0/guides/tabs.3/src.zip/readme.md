# Using TabPanels in Sencha Touch 2 #

TabPanels are useful to swapping between different pages of an app, with either top or bottom tabs.
