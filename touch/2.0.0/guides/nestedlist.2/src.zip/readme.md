# Using Nested Lists in Sencha Touch 2 #

Nested List provides a miller column interface to navigate between nested sets of data with a clean and easy to use interface.
