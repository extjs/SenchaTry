# Using Navigation Views in Sencha Touch 2 #

Navigation Views allow you to push items into a stack of views and provides built-in back button and animation support.
