# Getting Started with Sencha Touch 2 #

A short introduction to what Sencha Touch is and how to use it for your first app.
