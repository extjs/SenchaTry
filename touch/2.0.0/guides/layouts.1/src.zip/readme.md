# Using Layouts in Sencha Touch 2 #

Sencha Touch employs a powerful layout engine that makes it easy to size and position your components on screen.
