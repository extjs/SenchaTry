# Understanding and Using Events in Sencha Touch 2 #

Most classes and components in Sencha Touch 2 fire useful events that you can respond to. Here we take a look at how they work.
