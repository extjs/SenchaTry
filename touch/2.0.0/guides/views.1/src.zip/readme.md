# Using Views in your Applications #

Describes what is meant by a View in Sencha Touch 2 and how to use them in your apps.
