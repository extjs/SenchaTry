# Creating a custom component in Sencha Touch 2 #

The following example shows how you can create a simple custom component in Sencha Touch 2 by using the `Ext.define()` method.
