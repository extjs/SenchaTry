# Truncating strings in an XTemplate in Sencha Touch 2 #

The following example shows how you an truncate strings in an Ext.XTemplate in Sencha Touch 2 by using the `ellipsis()` method.
