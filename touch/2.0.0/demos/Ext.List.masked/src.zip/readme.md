# Setting a loading mask on an Ext.List component in Sencha Touch 2 #

The following example shows how you can apply a load mask to an Ext.List (list) control in Sencha Touch 2 by setting the `masked` config option to an Ext.LoadMask object.
