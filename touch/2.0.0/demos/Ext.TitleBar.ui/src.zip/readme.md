# Setting a title bar UI theme on an Ext.TitleBar container in Sencha Touch 2 #

The following example shows how you can set the title bar UI theme on an Ext.TitleBar container in Sencha Touch 2 by setting the `ui` config to `"dark"`, `"light"`, or `"neutral"`.
