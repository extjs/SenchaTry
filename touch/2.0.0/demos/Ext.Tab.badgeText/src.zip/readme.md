# Setting the badge text on an Ext.TabPanel container's tab in Sencha Touch 2 #

The following example shows how you can set the badge text on an Ext.TabPanel container's tab in Sencha Touch 2 by setting the `badgeText` config option and setting the `tabBarPosition` config option to `"bottom"`.
