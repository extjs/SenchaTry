# Allowing multiple selection on an Ext.List component in Sencha Touch 2 #

The following example shows how you can enable multiple item selection on an Ext.List component in Sencha Touch 2 by setting the `mode` config option.
