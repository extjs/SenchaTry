# Validating string lengths on an Ext.data.Model object using Sencha Touch 2 #

The following example shows how you can validate string lengths an Ext.store.Model object in Sencha Touch 2 by setting the `validations` object on the model and then creating a 'length' validation with a `min` and `max` attribute.
