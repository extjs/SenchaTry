# Setting the label width on an Ext.form.Field container in Sencha Touch 2 #

The following example shows how you can set the label width on an Ext.form.Field container in Sencha Touch 2 by setting the `labelWidth` config option or calling the `setLabelWidth()` method.
