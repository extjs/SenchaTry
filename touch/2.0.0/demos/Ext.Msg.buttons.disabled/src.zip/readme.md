# Disabling buttons on an Ext.MessageBox control in Sencha Touch 2 #

The following example shows how you can disable buttons on an Ext.Msg control in Sencha Touch 2 by setting the `disabled` config option on an item in the `buttons` config array.
