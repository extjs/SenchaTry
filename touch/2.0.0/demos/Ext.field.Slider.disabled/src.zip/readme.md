# Disabling the Ext.field.Slider control in Sencha Touch 2 #

The following example shows how you can disable an Ext.field.Slider control in Sencha Touch 2 by setting the Boolean `disabled` config option or by calling the `setDisabled()` method.
