# Grouping items in an Ext.List component in Sencha Touch 2 #

The following example shows how you can group items in an Ext.List component in Sencha Touch 2 by setting the Boolean `grouped` config option on the Ext.List component, specify the `grouper` config on the Ext.Store component, and set a `groupFn` function.
