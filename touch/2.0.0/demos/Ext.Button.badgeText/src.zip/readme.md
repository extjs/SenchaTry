# Setting badge text on an Ext.Button component using Sencha Touch 2 #

The following example shows how you can set the badge text on an Ext.Button component using Sencha Touch 2 by setting the `badgeText` config or using the `setBadgeText()` method.
