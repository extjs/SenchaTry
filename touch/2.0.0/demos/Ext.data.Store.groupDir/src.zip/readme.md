# Setting the group sorting direction an Ext.List component in Sencha Touch 2 #

The following example shows how you set the direction in which sorting should be applied when grouping an Ext.List (list) control in Sencha Touch 2 by setting the `groupDir` config option or calling the `setGroupDir()` and `sort()` methods at runtime.
