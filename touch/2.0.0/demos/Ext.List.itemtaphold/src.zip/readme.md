# Detecting when an item is swiped or tapped and held on an Ext.List component in Sencha Touch 2 #

The following example shows how you can listen for swipe and tap hold (long press) events on an Ext.List component in Sencha Touch 2 by specifying a `listener` object and listening for the `itemswipe` and `itemtaphold` events.
