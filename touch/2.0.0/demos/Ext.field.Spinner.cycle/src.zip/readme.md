# Toggling value wrapping on an Ext.field.Spinner control in Sencha Touch 2 #

The following example shows how you can toggle value wrapping on an Ext.field.Spinner (spinnerfield) component in Sencha Touch 2 by setting the Boolean `cycle` config option or by calling the `setCycle()` method at runtime.
