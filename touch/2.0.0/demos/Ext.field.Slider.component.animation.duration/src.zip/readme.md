# Setting the thumb animation duration on an Ext.field.Slider control in Sencha Touch 2 #

The following example shows how you can set the slider thumb animation speed on an Ext.field.Slider (sliderfield) control in Sencha Touch 2 by setting the `component` config option to an object containing an `animation` property and a nested `duration` object.
