# Creating an auto-closing Ext.ActionSheet container in Sencha Touch 2 #

The following example shows how you can create an auto-closing Ext.ActionSheet container in Sencha Touch 2 by calling the `hide()` method using the `setTimeout()` JavaScript method.
