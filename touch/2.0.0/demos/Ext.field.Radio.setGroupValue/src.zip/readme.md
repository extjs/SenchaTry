# Programmatically setting the selected item for an Ext.field.Radio control in Sencha Touch 2 #

The following example shows how you can programmatically set the select the item for an Ext.field.Radio control in Sencha Touch 2 by calling the `setGroupValue()` method.
