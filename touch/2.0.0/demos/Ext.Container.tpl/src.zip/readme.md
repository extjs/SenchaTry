# Creating a simple XTemplate list in Sencha Touch 2 #

The following example shows how you can create a simple list in an Ext.Container container in Sencha Touch 2 by specifying the `tpl` config object.

