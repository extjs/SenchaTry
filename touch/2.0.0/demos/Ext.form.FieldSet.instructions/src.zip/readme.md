# Setting the instructions on an Ext.form.FieldSet container in Sencha Touch 2 #

The following example shows how you can set the instructions on an Ext.form.FieldSet container in Sencha Touch 2 by using the `instructions` config option or calling the `setInstructions()` method.
