# Specifying a custom style for the pressed state on an Ext.SegmentedButton component in Sencha Touch 2 #

The following example shows how you can specify a custom button style for the pressed state on an Ext.SegmentedButton component in Sencha Touch 2 by setting the `pressedCls` config object to the name of a style in your stylesheet.
