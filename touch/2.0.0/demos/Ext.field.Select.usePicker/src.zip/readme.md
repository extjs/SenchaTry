# Toggling a picker on the Ext.field.Select control in Sencha Touch 2 #

The following example shows how you can specify whether the Ext.field.Select control in Sencha Touch 2 displays an Ext.picker.Picker component or an Ext.List popup overlay by setting the `usePicker` config option.
