# Adding a title header on an Ext.Picker control in Sencha Touch 2 #

The following example shows how you add a title header to an Ext.Picker (picker) control in Sencha Touch 2 by setting the `useTitle` config option or by calling the `setUseTitle()` method.
