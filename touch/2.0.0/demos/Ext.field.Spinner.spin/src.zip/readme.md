# Detecting when the user changes an Ext.field.Spinner control in Sencha Touch 2 #

The following example shows how you detect when the user changes an Ext.field.Spinner (spinnerfield) control in Sencha Touch 2 by listening for the `spin` event (or the `spinup` and `spindown` events separately).
