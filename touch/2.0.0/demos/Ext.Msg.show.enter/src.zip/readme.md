# Specifying which side of the viewport an Ext.Msg component animates from in Sencha Touch 2 #

The following example shows how you can specify which side of the viewport an Ext.Msg component animates from during a slide animation in Sencha Touch 2 by specifying the `enter` and `exit` config options to `"left"`, `"right"`, `"top"`, or `"bottom"`.
