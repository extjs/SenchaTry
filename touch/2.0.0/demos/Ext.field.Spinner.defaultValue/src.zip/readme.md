# Setting the default value for an Ext.field.Spinner in Sencha Touch 2 #

The following example shows how you can set the default value on an Ext.field.Spinner (spinnerfield) component in Sencha Touch 2 when no value is defined by setting the `defaultValue` config option.
