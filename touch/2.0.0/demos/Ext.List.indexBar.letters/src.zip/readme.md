# Filtering the index bar letters on an Ext.List component in Sencha Touch 2 #

The following example shows how you can filter which letters appear in an Ext.List component index bar in Sencha Touch 2 by passing an object to the `indexBar` config option and specifying an array of letters using the `letters` config option.
