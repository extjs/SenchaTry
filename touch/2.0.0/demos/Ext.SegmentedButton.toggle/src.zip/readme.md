# Detecting when an Ext.SegmentedButton component is toggled in Sencha Touch 2 #

The following example shows how you can detect when a user toggles an Ext.SegmentedButton component in Sencha Touch 2 by listening for the `toggle` event.
