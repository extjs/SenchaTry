# Specifying which side of the viewport an Ext.ActionSheet container animates from in Sencha Touch 2 #

The following example shows how you can specify which side of the viewport an Ext.ActionSheet container animates from in Sencha Touch 2 by setting the `enter` and `exit` config options.
