# Toggling the indicator on an Ext.List component loading mask in Sencha Touch 2 #

The following example shows how you can toggle the indicator on an Ext.List (list) control loading mask in Sencha Touch 2 by setting the Boolean `indicator` config option on the `masked` config Ext.LoadMask object, or by calling the `setIndicator()` method at runtime.
