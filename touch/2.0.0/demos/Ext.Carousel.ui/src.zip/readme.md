# Setting the indicator UI theme on the Ext.Carousel component in Sencha Touch 2 #

The following example shows how you can set the UI theme for the carousel indicators on an Ext.Carousel component in Sencha Touch 2 by setting the `ui` config option to either `"dark"` or `"light"`.
