# Creating a simple Ext.form.FormPanel with Sencha Touch 2 #

The following example shows how you can create a simple Ext.form.FormPanel with Sencha Touch 2 by creating an Ext.form.FormPanel (or Ext.form.Panel) instance and adding child items (such as textfields).
