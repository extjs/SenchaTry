# Pinning grouped headers on an Ext.List component in Sencha Touch 2 #

The following example shows how you can pin grouped item headers on an Ext.List component in Sencha Touch 2 by setting the Boolean `pinHeaders` config.
