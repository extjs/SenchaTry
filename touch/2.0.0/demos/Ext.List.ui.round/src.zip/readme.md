# Creating a rounded Ext.List component in Sencha Touch 2 #

The following example shows how you can create a rounded Ext.List component in Sencha Touch 2 by setting the `ui` config to `"round"`.
