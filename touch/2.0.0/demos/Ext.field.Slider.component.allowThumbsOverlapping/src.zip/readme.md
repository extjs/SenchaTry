# Allowing multiple thumbs to overlap on an Ext.field.Slider control in Sencha Touch 2 #

The following example shows how you can allow multiple thumbs to overlap on an Ext.field.Slider (sliderfield) control in Sencha Touch 2 by setting the Boolean `allowThumbsOverlapping` config option on the `component` object.
