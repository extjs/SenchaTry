# Getting the selected item value for an Ext.field.Radio control in Sencha Touch 2 #

The following example shows how you can get the currently selected value on an Ext.field.Radio control in Sencha Touch 2 by calling the `getGroupValue()` method or using the `getValues()` method.
