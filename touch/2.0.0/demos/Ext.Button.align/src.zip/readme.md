# Creating a simple Ext.TitleBar component using Sencha Touch 2 #

The following example shows how you can align Ext.Button components in an Ext.TitleBar container using Sencha Touch 2 by setting the `align` config.
