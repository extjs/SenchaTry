# Removing the indicator dots from an Ext.Carousel component using Sencha Touch 2 #

The following example shows how you can remove the indicator dots from an Ext.Carousel component using Sencha Touch 2 by setting the Boolean `indicator` config option to `false`.
