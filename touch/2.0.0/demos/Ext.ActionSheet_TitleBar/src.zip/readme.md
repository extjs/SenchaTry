# Adding a title to an Ext.ActionSheet container in Sencha Touch 2 #

The following example shows how you can add a simple title to an Ext.ActionSheet container in Sencha Touch 2 by nesting an Ext.TitleBar component.
