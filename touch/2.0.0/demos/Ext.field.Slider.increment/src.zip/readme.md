# Setting the thumb increment on an Ext.field.Slider control in Sencha Touch 2 #

The following example shows how you can set the increment step size on an Ext.field.Slider control in Sencha Touch 2 by setting the `increment` config option.
