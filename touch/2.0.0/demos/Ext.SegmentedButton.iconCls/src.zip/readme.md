# Adding icons to an Ext.SegmentedButton component in Sencha Touch 2 #

The following example shows how you can add icons to an Ext.SegmentedButton component in Sencha Touch 2 by setting the `iconCls` and `iconMask` config objects.
