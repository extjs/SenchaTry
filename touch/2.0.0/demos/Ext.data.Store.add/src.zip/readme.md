# Dynamically adding items to an Ext.List control in Sencha Touch 2 #

The following example shows how you can dynamically add items to an Ext.List (list) control in Sencha Touch 2 by calling the `add()` method on the data store.
