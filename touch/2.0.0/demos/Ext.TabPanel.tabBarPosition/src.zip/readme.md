# Setting the tab bar position on an Ext.TabPanel container in Sencha Touch 2 #

The following example shows how you can set the tab bar position on an Ext.TabPanel container in Sencha Touch 2 by setting the `tabBarPosition` config to `"bottom"` (default), or `"top"`.
