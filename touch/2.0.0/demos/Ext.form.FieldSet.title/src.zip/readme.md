# Setting the title on an Ext.form.FieldSet container in Sencha Touch 2 #

The following example shows how you can set the title on an Ext.form.FieldSet container in Sencha Touch 2 by using the `title` config option or calling the `setTitle()` method.
