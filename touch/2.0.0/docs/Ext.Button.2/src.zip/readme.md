# Ext.Button Example #

You can also create an Ext.Button with just an icon using the `iconCls` configuration.
