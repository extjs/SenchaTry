# Ext.Button Example #

Buttons also come with a range of different default UIs. Here are the included UIs available (if `$include-button-uis` is set to `true`):

* __normal__ - a basic gray button
* __back__ - a back button
* __forward__ - a forward button
* __round__ - a round button
* __action__ - shaded using the $base-color (dark blue by default)
* __decline__ - red
* __confirm__ - green
