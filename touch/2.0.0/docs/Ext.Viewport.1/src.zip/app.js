/*global Ext:false */
Ext.setup({
    viewport: {
        layout: 'vbox'
    },
    onReady: function() {
        Ext.Msg.alert('do something');
    }
});
