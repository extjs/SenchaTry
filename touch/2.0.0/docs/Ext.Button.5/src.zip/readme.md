# Ext.Button Example #

This example shows a bunch of icons on the screen in two toolbars. When you click on the center button, it switches the `iconCls` on every button on the page.
