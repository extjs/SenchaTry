# Ext.Button Example #

Buttons can also have a badge on them, by using the `badgeText` configuration.
