# Ext.Button Example #

Here is an Ext.Button is it's simplist form.
