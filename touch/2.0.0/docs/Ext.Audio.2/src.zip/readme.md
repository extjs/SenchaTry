# Ext.Audio Example #

You can also set the `hidden` configuration of the Ext.Audio component to `true` by default, and then control the audio by using the `play()`, `pause()` and `toggle()` methods.
