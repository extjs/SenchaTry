# Ext.Audio Example #

Here is an example of the Ext.Audio component in a fullscreen container.
