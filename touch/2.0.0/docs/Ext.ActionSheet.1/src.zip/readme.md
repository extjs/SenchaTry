# Ext.ActionSheet Example #

As you can see from the following example, you no longer have to specify an xtype when creating buttons within an ActionSheet, because the `defaultType` is set to button.
