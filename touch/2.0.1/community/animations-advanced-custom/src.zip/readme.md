# Advanced Custom Animations with Touch 2 #

Via [Bruno Tavares](http://bruno.tavares.me/).
