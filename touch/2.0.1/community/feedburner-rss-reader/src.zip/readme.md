# FeedBurner RSS Reader #

FeedBurner RSS Reader MVC application Developed using Sencha Touch 2

This application developed using Sencha Touch 2, allows to read FeedBurner Feeds supporting some interesting features like:

- History
- Deep Linking
- DataView Components
- Custom Card Layout animation
- Custom JsonP proxy
- LocalStorage

Via [Andrea Cammarata](http://www.andreacammarata.com/).
