<h1>FeedBurner RSS Reader</h1>
<p>FeedBurner RSS Reader MVC application Developed using Sencha Touch 2 RC</p>