# Animate Button #

How to animate components.

Via [Bruno Tavares](http://bruno.tavares.me/).
