# Path like menu #

Demo:  
Git Repo: [https://bitbucket.org/nilsdehl/sencha-touch-2-path-like-menu/](bitbucket.org/nilsdehl/sencha-touch-2-path-like-menu/)
Blogpost: [http://www.nils-dehl.de/2012/04/path-like-menu-for-senchatouch-2/](www.nils-dehl.de/2012/04/path-like-menu-for-senchatouch-2/)

by 

Nils Dehl

w: [http://nils-dehl.de/](http://nils-dehl.de/)
t: [@nilsdehl](http://twitter.com/nilsdehl)
m: mail(at)nils-dehl.de
