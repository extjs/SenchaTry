# Load the sencha-touch framework automatically.
load "../../sdk/resources/themes"

# Compass configurations
sass_path = ""
css_path = "../css"

# Require any additional compass plugins here.
images_dir = "../images"
output_style = :compressed
environment = :production
