/*global Ext:false */
Ext.setup({
    viewport: {
        layout: 'vbox'
    },
    onReady: function() {
        //do something
    }
});
