/*global Ext:false */
Ext.application({
    launch: function() {
        Ext.Msg.alert('Title', 'The quick brown fox jumped over the lazy dog.', Ext.emptyFn);
    }
});
