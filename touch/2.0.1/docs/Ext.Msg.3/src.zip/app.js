/*global Ext:false */
Ext.application({
    launch: function() {
        Ext.Msg.confirm("Confirmation", "Are you sure you want to do that?", Ext.emptyFn);
    }
});
