# Toggling the clear icon on an Ext.field.Text control in Sencha Touch 2 #

The following example shows how you can toggle the clear icon on an Ext.field.Text control in Sencha Touch 2 by using the Boolean `clearIcon` config option.
