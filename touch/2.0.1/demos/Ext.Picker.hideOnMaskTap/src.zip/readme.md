# Closing an Ext.Picker control by clicking on the modal mask in Sencha Touch 2 #

The following example shows how you can close an Ext.Picker control by clicking on the modal mask in Sencha Touch 2 by setting the Boolean `hideOnMaskTap` config option or by calling the `setHideOnMaskTap()` method.
