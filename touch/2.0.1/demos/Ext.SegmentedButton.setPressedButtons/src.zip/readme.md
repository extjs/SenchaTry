# Programmatically selecting items in Ext.SegmentedButton component in Sencha Touch 2 #

The following example shows how you can programmatically select (or clear) items in an Ext.SegmentedButton component in Sencha Touch 2 by calling the `setPressedButtons()` method and passing an array of button indexes to select.
