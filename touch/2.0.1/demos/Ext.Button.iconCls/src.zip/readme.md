# Adding icons to an Ext.Button component using Sencha Touch 2 #

The following example shows how you can add an icon to an Ext.Button component using Sencha Touch 2 by setting the `iconCls` and `iconMask` configs.
