# Determining if an image successfully loaded using the Ext.Img component in Sencha Touch 2 #

The following example shows how you can determine whether an image was able to be successfully loaded using the Ext.Img component in Sencha Touch 2 by using the `listeners` config object and listening for the `load` and/or `error` events.
