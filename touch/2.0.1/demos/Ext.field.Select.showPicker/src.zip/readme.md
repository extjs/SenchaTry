# Programmatically opening an Ext.field.Select control in Sencha Touch 2 #

The following example shows how you can programmatically open an Ext.field.Select control in Sencha Touch 2 by using the `showPicker()` method.
