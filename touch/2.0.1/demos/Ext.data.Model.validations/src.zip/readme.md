# Validating an Ext.data.Model object using Sencha Touch 2 #

The following example shows how you can validate an Ext.store.Model object in Sencha Touch 2 by setting the `validations` object on the model and then calling the `validate()` method on a model instance.
