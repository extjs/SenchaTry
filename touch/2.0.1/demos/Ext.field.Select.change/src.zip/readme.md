# Getting the selected item value for an Ext.field.Select control in Sencha Touch 2 #

The following example shows how you can get the currently selected value of an Ext.field.Select control in Sencha Touch 2 by using the `getValue()` method or using the `change` event.
