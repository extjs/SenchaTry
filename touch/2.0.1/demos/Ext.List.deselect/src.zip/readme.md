# Preventing items from being selected in an Ext.List component in Sencha Touch 2 #

The following example shows how you can prevent items from being selected in an Ext.List (list) control in Sencha Touch 2 by listening for the `select` event and calling the `deselect()` method.
