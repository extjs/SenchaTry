# Creating a simple carousel using the Ext.Carousel component in Sencha Touch 2 #

The following example shows how you can create a simple carousel using the Ext.Carousel component in Sencha Touch 2.
