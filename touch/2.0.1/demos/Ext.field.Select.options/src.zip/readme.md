# Setting a list of options on an Ext.field.Select control in Sencha Touch 2 #

The following example shows how you can specify the items in an Ext.field.Select (selectfield) control by setting the `options` config option or by calling the `setOptions()` method at runtime.
