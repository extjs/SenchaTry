# Setting the increment value for an Ext.field.Spinner in Sencha Touch 2 #

The following example shows how you can set the increment value on an Ext.field.Spinner (spinnerfield) component in Sencha Touch 2 by setting the `increment` config option.
