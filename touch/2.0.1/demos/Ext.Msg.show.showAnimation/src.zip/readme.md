# Setting animations when an Ext.Msg component is shown or hidden in Sencha Touch 2 #

The following example shows how you can add an animation when an Ext.Msg component is shown or hidden in Sencha Touch 2 by passing the `showAnimation` and/or `hideAnimation` config option to the `Ext.Msg.show()` method.
