# Grouping the increment/decrement buttons on an Ext.field.Spinner control in Sencha Touch 2 #

The following example shows how you can group the increment/decrement buttons on an Ext.field.Spinner (spinnerfield) component in Sencha Touch 2 by setting the Boolean `groupButtons` config option.
