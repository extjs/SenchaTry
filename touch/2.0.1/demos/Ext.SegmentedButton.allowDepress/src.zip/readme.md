# Preventing an Ext.SegmentedButton component from being deselected in Sencha Touch 2 #

The following example shows how you can prevent an Ext.SegmentedButton component from being deselected in Sencha Touch 2 by setting the Boolean `allowDepress` config option to `false`.
