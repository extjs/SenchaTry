# Programmatically changing the active item on an Ext.Carousel component in Sencha Touch 2 #

The following example shows how you can programmatically change the active item in an Ext.Carousel componenent using Sencha Touch 2 and the `next()` method.
