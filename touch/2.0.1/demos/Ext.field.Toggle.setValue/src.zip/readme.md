# Programmatically setting an Ext.field.Toggle control in Sencha Touch 2 #

The following example shows how you programmatically set an Ext.field.Toggle (togglefield) control in Sencha Touch 2 by calling the `toggle()` or `setValue()` methods.
