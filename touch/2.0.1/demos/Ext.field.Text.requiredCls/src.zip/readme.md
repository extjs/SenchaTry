# Styling the required indicator on an Ext.field.Text control in Sencha Touch 2 #

The following example shows how you can style the "required" indicator text by on an Ext.field.Field control [in this case an Ext.field.Text (textfield) control] by creating a CSS selector and specifying the `requiredCls` config option.
