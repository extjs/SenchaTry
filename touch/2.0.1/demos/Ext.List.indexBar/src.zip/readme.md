# Displaying an index bar on an Ext.List component in Sencha Touch 2 #

The following example shows how you can add an index bar on an Ext.List component in Sencha Touch 2 by setting the Boolean `indexBar` config option to `true`.
