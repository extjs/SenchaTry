# Setting the icon alignment on an Ext.Button component using Sencha Touch 2 #

The following example shows how you can align the icon within an Ext.Button component using Sencha Touch 2 by setting the `iconAlign` config to `"top"`, `"bottom"`, `"left"`, or `"right"`.
