# Determining the current device's browser settings using Sencha Touch 2 #

The following example shows how you can determine the current device's browser settings by using the properties in the `Ext.browser` class.
