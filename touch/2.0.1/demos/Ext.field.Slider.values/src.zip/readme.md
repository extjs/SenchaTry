# Adding multiple thumbs to an Ext.field.Slider control in Sencha Touch 2 #

The following example shows how you can add multiple thumbs to an Ext.field.Slider control in Sencha Touch 2 by setting the `values` config to an array of values.
