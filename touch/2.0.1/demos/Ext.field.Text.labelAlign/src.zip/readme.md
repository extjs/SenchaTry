# Setting the label alignment on an Ext.field.Text control in Sencha Touch 2 #

The following example shows how you can set the label alignment on an Ext.field.Text (textfield) control in Sencha Touch 2 by setting the `labelAlign` config option or by calling the `setLabelAlign()` method at runtime.
