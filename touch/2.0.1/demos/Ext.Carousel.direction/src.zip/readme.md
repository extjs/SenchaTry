# Creating a vertically scrolling Ext.Carousel component in Sencha Touch 2 #

The following example shows how you can create a vertically scrolling Ext.Carousel component using Sencha Touch 2 by setting the `direction` config option to `"vertical"`.
