# Filtering data in an Ext.List component in Sencha Touch 2 #

The following example shows how you filter the data store on an Ext.List (list) control in Sencha Touch 2 by setting the `filters` config option or calling the `clearFilter()` and `filter()` methods at runtime.
