# Displaying an Ext.ActionSheet container in Sencha Touch 2 #

The following example shows how you can toggle an Ext.ActionSheet container in Sencha Touch 2 by using the `show()` and `hide()` methods.
