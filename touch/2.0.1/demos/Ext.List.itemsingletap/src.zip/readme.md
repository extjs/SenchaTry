# Detecting when an item is single or double tapped on an Ext.List component in Sencha Touch 2 #

The following example shows how you can listen for single and double tap events on an Ext.List component in Sencha Touch 2 by specifying a `listener` object and listening for the `itemsingletap` and `itemdoubletap` events.
