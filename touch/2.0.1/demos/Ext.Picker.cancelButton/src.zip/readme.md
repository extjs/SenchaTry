# Removing the cancel button on an Ext.Picker dialog in Sencha Touch 2 #

The following example shows how you can remove the cancel button on an Ext.Picker dialog in Sencha Touch 2 by setting the `cancelButton` config option to `false`.
