# Setting text alignment on an Ext.picker.Slot control in Sencha Touch 2 #

The following example shows how you can set the text alignment on an Ext.picker.Slot (pickerslot) control in Sencha Touch 2 by setting the `align` config option.
