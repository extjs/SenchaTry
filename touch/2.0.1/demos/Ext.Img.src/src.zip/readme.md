# Displaying an image using the Ext.Img component in Sencha Touch 2 #

The following example shows how you can display an image using the Ext.Img component in Sencha Touch 2.
