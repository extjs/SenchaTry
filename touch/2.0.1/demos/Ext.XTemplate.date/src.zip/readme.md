# Formatting dates in an XTemplate in Sencha Touch 2 #

The following example shows how you can format dates in an Ext.XTemplate in Sencha Touch 2 by passing an optional date format string to the `date()` method (the default format is "m/d/Y" &mdash; ie, "02/09/1949").
