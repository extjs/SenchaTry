# Populating an Ext.form.Panel container from a model using Sencha Touch 2 #

The following example shows how you can populate the field in an Ext.form.Panel (formpanel) container in Sencha Touch 2 by calling the `setRecord()` method and passing an Ext.data.Model instance.
