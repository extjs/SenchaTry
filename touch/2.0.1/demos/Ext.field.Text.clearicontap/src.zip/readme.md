# Determining when a user clicks the clear icon on an Ext.field.Text control in Sencha Touch 2 #

The following example shows how you can determine when a user taps the clear icon on an Ext.field.Text control in Sencha Touch 2 by listening for the `clearicontap` event.
