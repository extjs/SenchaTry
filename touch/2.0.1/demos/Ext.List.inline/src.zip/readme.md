# Creating an inline list using an Ext.List control in Sencha Touch 2 #

The following example shows how you create an inline list using an Ext.List (list) control in Sencha Touch 2 by setting the `inline` config option or calling the `setInline()` method at runtime.
