# Fading between items in an Ext.TabPanel container in Sencha Touch 2 #

The following example shows how you can fade between items in an Ext.TabPanel container in Sencha Touch 2 by specifying a card layout and setting the `animation` config to `"fade"`.
