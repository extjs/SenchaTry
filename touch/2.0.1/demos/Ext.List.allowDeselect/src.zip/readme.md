# Allowing an item to be deselected on an Ext.List component in Sencha Touch 2 #

The following example shows how you can allow an item to be deselected on an Ext.List component in Sencha Touch 2 by setting the Boolean `allowDeselect` config object to `true`.
