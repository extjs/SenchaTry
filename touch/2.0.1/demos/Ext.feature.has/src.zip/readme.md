# Determining if the user's browser supports a certain feature using Sencha Touch 2 #

The following example shows how you can verify if a browser feature exists on the current device by using the properties in the `Ext.feature.has` class.
