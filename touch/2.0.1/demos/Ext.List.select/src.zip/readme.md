# Programmatically selecting items in an Ext.List component in Sencha Touch 2 #

The following example shows how you can programmatically items in an Ext.List (list) control in Sencha Touch 2 by calling the `select()` or `selectAll()` method.
