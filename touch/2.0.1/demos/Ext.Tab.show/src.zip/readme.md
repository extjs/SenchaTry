# Determining when the active item changes on an Ext.TabPanel container in Sencha Touch 2 #

The following example shows how you can detect when a specific tab is hidden or shown on an Ext.TabPanel container in Sencha Touch 2 by listening for the `show` and/or `hide` events on a TabPanel item.
