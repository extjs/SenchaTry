# Detecting when the user cancels an Ext.Picker dialog in Sencha Touch 2 #

The following example shows how you can detect when the user cancels an Ext.Picker component dialog in Sencha Touch 2 by listening for the `cancel` event.
