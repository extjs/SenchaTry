# Styling the cancel and done buttons on an Ext.Picker dialog in Sencha Touch 2 #

The following example shows how you can style the cancel and done buttons on an Ext.Picker dialog in Sencha Touch 2 by adding the `ui` config option within the `cancelButton` and `doneButton` config options.
