# Preventing items from being selected in an Ext.List component in Sencha Touch 2 #

The following example shows how you can apply styles to the pressed item state in an Ext.List (list) control in Sencha Touch 2 by setting the `pressedCls` config option to a style name.
