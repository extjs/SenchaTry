# Setting UI styles on an Ext.Button component using Sencha Touch 2 #

The following example shows how you can set various UI styles on an Ext.Button component using Sencha Touch 2 and setting the `ui` config option to one of the following values: `"normal"` (default), `"round"`, `"back"`, `"forward"`, `"small"`, `"action"`, `"decline"`, or `"confirm"`.
