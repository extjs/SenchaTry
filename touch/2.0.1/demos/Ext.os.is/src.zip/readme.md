# Determining the current device's operating system using Sencha Touch 2 #

The following example shows how you can determine which operating system the current device is running by using the properties in the `Ext.os` class.
